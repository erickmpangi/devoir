import time
import sys
import csv
from datetime import datetime

def stable_matching(_, proposer, proposer_prefs, receiver_prefs):
    # Initialize variables
    free_proposers = list(proposer_prefs.keys())
    engaged = {}
    proposals = {proposer: 0 for proposer in free_proposers}

    # Create a reverse dictionary for the receivers' preferences
    reverse_prefs = {
        receiver: {proposer: rank for rank, proposer in enumerate(prefs)}
        for receiver, prefs in receiver_prefs.items()
    }

    while free_proposers:
        proposer = free_proposers[0]

        # Check if the proposer still has preferences to propose
        if proposals[proposer] >= len(proposer_prefs[proposer]):
            raise ValueError(f"Invalid preference list for {proposer}, missing preferences.")

        # Select the next receiver from the proposer's preference list
        receiver = proposer_prefs[proposer][proposals[proposer]]
        proposals[proposer] += 1

        if receiver not in engaged:
            # If the receiver is not engaged, engage them with the proposer
            engaged[receiver] = proposer
            free_proposers.pop(0)
        else:
            # If the receiver is already engaged, compare preferences
            current_partner = engaged[receiver]
            if reverse_prefs[receiver][proposer] < reverse_prefs[receiver][current_partner]:
                # If the new proposer is preferred, update the engagement
                engaged[receiver] = proposer
                free_proposers.pop(0)
                free_proposers.append(current_partner)

    # Sort the results according to the order of the proposers
    proposers_order = list(proposer_prefs.keys())
    return sorted([(proposer, receiver) for receiver, proposer in engaged.items()], key=lambda pair: proposers_order.index(pair[0]))

def write_execution_time_to_csv(execution_time, start_time):
    # Open the CSV file to append the execution time
    with open('execution_times.csv', mode='a', newline='') as file:
        writer = csv.writer(file)
        # If the file is empty, write the header
        if file.tell() == 0:
            writer.writerow(["Start Date and Time", "Execution Time (seconds)"])
        writer.writerow([start_time.strftime("%Y-%m-%d %H:%M:%S"), execution_time])

if __name__ == "__main__":
    # Measure the start time
    start_time = datetime.now()

    # Read the first line (number of participants and gender of proposers)
    first_line = sys.stdin.readline().strip().split()
    if len(first_line) != 2:
        raise ValueError("Invalid input format: First line must contain exactly two values (N and 'm' or 'w').")

    n = int(first_line[0])
    proposer = first_line[1]

    # Read the preferences of men
    men_prefs = {}
    for _ in range(n):
        data = sys.stdin.readline().strip().split()
        if len(data) != n + 1:
            raise ValueError(f"Invalid preferences list for {data[0]}. Expected {n} preferences.")
        men_prefs[data[0]] = data[1:]

    # Read the preferences of women
    women_prefs = {}
    for _ in range(n):
        data = sys.stdin.readline().strip().split()
        if len(data) != n + 1:
            raise ValueError(f"Invalid preferences list for {data[0]}. Expected {n} preferences.")
        women_prefs[data[0]] = data[1:]

    # Call the stable_matching function with the correct inputs
    if proposer == 'm':
        result = stable_matching(n, proposer, men_prefs, women_prefs)
    else:
        result = stable_matching(n, proposer, women_prefs, men_prefs)

    # Display the results
    for proposer, receiver in result:
        print(proposer, receiver)

    # Measure the execution time
    end_time = time.time()
    execution_time = end_time - start_time.timestamp()

    # Record the execution time and start date in the CSV file
    write_execution_time_to_csv(execution_time, start_time)
